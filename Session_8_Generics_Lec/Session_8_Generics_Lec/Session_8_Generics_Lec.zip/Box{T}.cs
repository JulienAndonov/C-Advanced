﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {
        private List<T> list { get; set; }

        public int Count { get; private set; }

        public T Remove()
        {
            var lastValueIndex = this.list.Count - 1;
            var lastValue = this.list[lastValueIndex];
            this.list.RemoveAt(lastValueIndex);
            this.Count--;
            return lastValue;
        }

        public void Add(T value)
        {
            this.list.Add(value);
            this.Count++;
        }

        public Box()
        {
            this.list = new List<T>();
        }
    }
}