﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace DefiningClasses
{
    class StartUp
    {
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>();
            int numOfEmployees = int.Parse(Console.ReadLine());

            for (int i = 0; i < numOfEmployees; i++)
            {
                var employeesEntries = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                var name = employeesEntries[0];
                var salary = decimal.Parse(employeesEntries[1]);
                var position = employeesEntries[2];
                var department = employeesEntries[3];
                var email = (employeesEntries.Length >= 5 ? employeesEntries[4] : "n/a");
                var age = int.Parse(employeesEntries.Length >= 6 ? employeesEntries[5] : "-1") ;

                
                var currentEmployee = new Employee(name, salary, position, department, email, age);
                employees.Add(currentEmployee);
            }

            string bestPaidDept = employees
                .GroupBy(e => e.Department)
                .Select(g => new { Department = g.Key, AvgSalary = g.Average(e => e.Salary)})
                .OrderByDescending(o => o.AvgSalary)
                .First()
                .Department;


            Console.WriteLine($"Highest Average Salary: {bestPaidDept}");


            foreach (var employee in employees.Where(e => e.Department == bestPaidDept).OrderByDescending(s => s.Salary))
            {
                Console.WriteLine($"{employee.Name} {employee.Salary} {employee.Email} {employee.Age}");
            }

            
        }
    }
}
