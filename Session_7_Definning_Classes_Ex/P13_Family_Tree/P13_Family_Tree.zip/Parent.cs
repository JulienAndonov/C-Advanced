﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Parent

    {

        public string ParentName { get; set; }



        public string ParentBirthDay { get; set; }

    }
}
