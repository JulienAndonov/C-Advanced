﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Child

    {

        public string ChildName { get; set; }



        public string ChildBirthday { get; set; }



    }
}
